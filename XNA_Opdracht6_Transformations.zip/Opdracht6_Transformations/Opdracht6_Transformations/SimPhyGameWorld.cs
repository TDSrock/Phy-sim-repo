﻿#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.GamerServices;
#endregion

namespace Opdracht6_Transformations
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class SimPhyGameWorld : Game
    {
        GraphicsDeviceManager graphDev;
        Color background = new Color(20, 0, 60);
        public static SimPhyGameWorld World;
        Vector3 cameraPosition = new Vector3(0, 30, 80);
        public Matrix View;
        public Matrix Projection;
        public static GraphicsDevice Graphics;

        List<Sphere> spheres;

        Sphere sun;

        public SimPhyGameWorld()
            : base()
        {
            Content.RootDirectory = "Content";

            World = this;
            graphDev = new GraphicsDeviceManager(this);
        }
        protected override void Initialize()
        {
            Graphics = GraphicsDevice;

            graphDev.PreferredBackBufferWidth = 1280;
            graphDev.PreferredBackBufferHeight = 800;
            graphDev.IsFullScreen = false;
            graphDev.ApplyChanges();

            SetupCamera(true);

            Window.Title = "HvA - Simulation & Physics - Opdracht 6 - Transformations - press <> to rotate camera";

            spheres = new List<Sphere>();

            // Step 1: Study the way the Sphere class is used in Initialize()
            // Step 2: Scale the sun uniformly (= the same factor in x, y and z directions) by a factor 2
            spheres.Add(sun = new Sphere(Matrix.Identity, Color.Yellow, 30));
            // Step 3: Create an earth Sphere, with radius, distance and color as given in the assignment

            // Step 4: Create 4 other planets: mars, jupiter, saturnus, uranus (radius, distance and color as given)
            // Step 5: Randomize the orbital rotation (in the Y plane) relative to the sun for each planet
            
            // Step 7: Create the moon (radius, distance and color as given)
            

            // Bonus: Create a bone transform class for spheres, with a parent transform (anchor position for the first bone), orientation and length/scale,
            // and let the creation and animation of the spheres be handled by that class.


            // Step 11: Create the Michelin man

            // Create the body, scales and positions below
            // body1, scale: (2.9f, 1.3f, 2.5f), position: (0f, 18.7f, 0f)
            // body2, scale: (3.1f, 1.5f, 2.7f), position: (0f, 20f, 0f)
            // body3, scale: (3.0f, 1.5f, 2.6f), position: (0f, 21.5f, 0f)
            // body4, scale: (2.7f, 1.3f, 2.4f), position: (0f, 22.8f, 0f)

            // Create the Michelin man Left arm
            // Create the upper left arm
            // scale: (1.6f, 1.0f, 1.0f), anchor(!) position: (2.3f, 22.8f, 0f)
            // rotate upper left arm by -0.3f along the Z axis

            // Create the left elbow
            // scale: (1.0, 0.9f, 0.9f), center position: 1f along the frame of the left upper arm

            // Create the lower left arm
            // scale: (1.4f, 0.9f, 0.9f), anchor(!) position: 1f along the frame of the left upper arm (same as elbow)
            // rotate lower left arm by 1.6f along the Z axis, relative to the orientation of the upper left arm

            // Create the left hand
            // scale: (1.4f, 0.9f, 0.9f), anchor(!) position: 0.6f along the frame of the lower left arm
            // rotate left hand by 0.1f along the Z axis, relative to the orientation of the lower left arm


            // Bonus: Create the Michelin man Right arm (mirror the left one's positions and rotations)


            // Create the Michelin man Left leg
            // Create the upper left leg
            // scale: (2.0f, 1.7f, 1.7f), anchor(!) position: (1.4f, 17.5f, 0f)
            // rotate upper left leg by -0.7f along the Y axis, -1.5f along the Y axis, -0.2f along the X axis.

            // Create the left knee
            // scale: (1.3f, 1.3f, 1.3f), center position: 1f along the frame of the left upper leg
            
            // Create the lower left leg
            // scale: (2.0f, 1.5f, 1.5f), anchor(!) position: 1f along the frame of the left upper leg (same as knee)
            // rotate lower left leg by 1.4f along the X axis, relative to the orientation of the upper left leg
            
            // Create the left foot
            // scale: (1.8f, 1.0f, 0.7f), anchor(!) position: 0.6f along the frame of the lower left leg
            // rotate left foot by -1.4f along the X axis, relative to the orientation of the lower left leg
            

            // Bonus: Create the Michelin man Right leg (mirror the left one's positions and rotations)


            // Create the Michelin man Neck and head
            // neck, scale: (1.4f, 1.2f, 1.3f), position: (0f, 24f, 0f)
            // head1, scale: (2.0f, 1.2f, 1.7f), position: (0f, 25f, 0f)
            // head2, scale: (1.4f, 1.4f, 1.4f), position: (0f, 25.8f, 0f)
            
            
            // Bonus: Give the Michelin man eyes
            

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            base.LoadContent();

            IsMouseVisible = true;
        }

        private void SetupCamera(bool initialize = false)
        {
            View = Matrix.CreateLookAt(cameraPosition, new Vector3(0, 0, 0), new Vector3(0, 1, 0));
            if(initialize) Projection = Matrix.CreatePerspectiveFieldOfView(MathHelper.PiOver4, SimPhyGameWorld.World.GraphicsDevice.Viewport.AspectRatio, 1.0f, 300.0f);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(background);

            foreach (Sphere sphere in spheres)
            {
                sphere.Draw();
            }

            base.Draw(gameTime);
        }

        protected override void Update(GameTime gameTime)
        {
            if (Keyboard.GetState().IsKeyDown(Keys.Right))
            {
                // Step 10: Make the camera position rotate around the origin depending on gameTime.ElapsedGameTime.TotalSeconds

                SetupCamera();
            }
            else if (Keyboard.GetState().IsKeyDown(Keys.Left))
            {
                // Step 10: Make the camera position rotate around the origin depending on gameTime.ElapsedGameTime.TotalSeconds

                SetupCamera();
            }
            
            // Step 6: Make the planets rotate, all with different speeds between 0.15 and 0.5 (radians) per second

            // Step 7: Make the moon rotate around the earth, speed 1.5
            // Step 8: Change the orbit of the moon such that it is rotated 45 degrees toward the sun/origin(see example!)

            // Step 12: Animate the lower arm and handSphere objects using Math.Sin()such that the man waves


            // Bonus: make the legs walk usingdifferent sine timings


            // Bonus: the eyes must blinkat random intervals between2 and 5 seconds


            base.Update(gameTime);
        }
    }
}
